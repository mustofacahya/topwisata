All documents in this Repository are licensed by contributors under the [W3C Software and Document license](http://www.w3.org/Consortium/Legal/copyright-software).
